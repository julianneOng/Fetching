from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.home, name="/"),
    path('blogs/',views.blogs,name="blogs"),
    path('viewblog/<int:pk>', views.viewblog, name="viewblog"),
    path('add-blog',views.addblog, name="addblog"),

]