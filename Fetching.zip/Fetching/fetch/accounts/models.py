from django.db import models
from django.db.models.deletion import SET_DEFAULT,SET_NULL

# Create your models here.
class BlogCategory(models.Model):
    name = models.CharField(max_length=191, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    
    def __str__(self):
        return self.name
class Blogs(models.Model):
    category = models.ForeignKey("BlogCategory", on_delete= SET_NULL, null=True)     
    title = models.CharField(max_length=191,null=True)
    description = models.CharField(max_length=500,null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return self.title