from django.forms import ModelForm, fields
from django import forms
from .models import Blogs

class BlogForm(ModelForm):
    title = forms.CharField(widget = forms.TextInput(attrs={'class':'form-control'}))
    description = forms.CharField(widget = forms.TextInput(attrs={'class':'form-control'}))
    class Meta:
        model = Blogs
        fields = '__all__'