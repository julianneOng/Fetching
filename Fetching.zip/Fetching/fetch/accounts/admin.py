from django.contrib import admin
from .models import Blogs, BlogCategory

# Register your models here.

admin.site.register(Blogs)
admin.site.register(BlogCategory)

