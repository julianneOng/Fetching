from django.shortcuts import redirect, render
from .models import Blogs
from .forms import BlogForm
from django.contrib import messages
# Create your views here.

def home(request):
    return render(request,'accounts/index.html')

def blogs(request):
    form = Blogs.objects.all()
    context = {'form':form}
    return render(request, 'accounts/index.html', context)

def viewblog(request, pk):
    blogs = Blogs.objects.get(id=pk)
    context = {'blogs': blogs}
    return render(request, 'accounts/view.html', context)

def addblog(request):
    form = BlogForm
    if request.method == 'POST':
        form = BlogForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Blog added Successfully")
            return redirect('blogs')
    context = {'form':form}
    return render(request, 'accounts/add.html', context)